<!doctype html>
    <html lang="en">
        <head>
            <link href="<?php echo url('assets/jquery.dataTables.min.css'); ?>" rel="stylesheet">
            <link href="<?php echo url('assets/bootstrap.min.css'); ?>" rel="stylesheet">
            <script src="<?php echo url('assets/jquery.js'); ?>"></script> 
            <script src="<?php echo url('assets/jquery.dataTables.min.js'); ?>"></script>
            <script src="<?php echo url('assets/bootstrap.min.js'); ?>"></script>
        </head>
        <body class="text-center">
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </body>
</html><?php /**PATH /home/soncy/employee-app/resources/views/layouts/master.blade.php ENDPATH**/ ?>